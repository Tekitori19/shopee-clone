<?php

loadPartial("head");
loadPartial("navbar");
loadPartial("success");
